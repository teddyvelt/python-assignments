# =============================================================================
# main.py  -  STARTER for this week's lab: a Morse SEND / RECEIVE station
#
# What is given to you:
#   - the exception that picks the hardware layer (hal_pico on a Pico / Wokwi,
#     hal_pc on your PC)
#   - a short DEMO that shows how to use the photoresistor
#   - the station loop that asks "send or receive?" each round
#
# What YOU write (this is the lab):
#   - send_message(message)   week 9 you wrote how to send a word, now (week 10)extend to a whole message (add word gaps)
#   - receive()               week 10, read the photoresistor and decode the message
#
# =============================================================================

# NEW in WEEK 10 - replace the hal_pico import and hal_pc imports with this try/except. 
# It will pick the right one for you, and you can run the same code on a Pico or on your PC.
try:
    import hal_pico as hw
except ImportError:
    import hal_pc as hw

import morse_code


# =============================================================================
# DEMO - how to use the photoresistor  (run it once, then delete this part)
# =============================================================================
# You read the photoresistor through the HAL, just like the LED: hw.read_u16()
# gives a NUMBER - about 900 when the light is on, about 100 when it is off.
# (For this demo, hw.play(...) makes the fake sensor "see" a message; with a
# real sensor the light comes from a real sender instead.) It changes its value
# every 1 ms on its own, in the BACKGROUND.
#
# Notice we only READ it every 100 ms here, even though it is changing every
# 1 ms. How often YOU read it is your SAMPLING RATE - and that decides how many
# reads make a dot. Turning the numbers into dots and letters is your job.
print("DEMO: reading the photoresistor while it plays the letter 'E'")
hw.play("E")                            # make the fake sensor "see" the letter E
count = 0
while count < 10:
    value = hw.read_u16()               # <-- this is how you read the sensor
    print("   read_u16() =", value)
    hw.sleep_ms(100)                    # our sampling rate for this demo
    count = count + 1
print("DEMO done.")
print("")


# =============================================================================
# WEEK9 Lab - you sent a word
# WEEK10 Lab - extend to send a whole message
# =============================================================================
def send_message(message):
    # TODO: flash the *entire* message on the LED, one dot/dash at a time.
    print("  (send_message to be completed)")

# =============================================================================
# WEEK10 Lab - read the photo resistor and decode the message
# =============================================================================
def receive():
    # TODO: read the photoresistor over and over and decode what it is playing.
    #
    #  1. SAMPLE AT A STEADY RATE. Read, then hw.sleep_ms(morse_code.SAMPLE_MS),
    #     and repeat, so every read takes about the same time. SAMPLE_MS is small
    #     (a few ms), so you get several reads inside one dot. (Using the shared
    #     SAMPLE_MS also lets you turn on STEP_MODE in photoresistor.py to step
    #     through this in a debugger - see the note at the top of that file.)
    #  2. WORK OUT HOW MANY READS MAKE A DOT:  morse_code.DOT_MS / morse_code.SAMPLE_MS.
    #     That is how you will tell a dot from a dash (a dash is about 3x as many).
    #  3. Each read:  value = hw.read_u16().  Above ~500 means the light is ON.
    #  4. COUNT how many reads the light stays on or off. Short on = dot, long on
    #     = dash. For the gaps: short = symbol gap, medium = letter gap, long =
    #     word gap.
    #  5. Build up a pattern like "..." and use morse_code.decode_pattern(pattern)
    #     to turn it into a letter. Add a space on a word gap.
    #   Return the decoded text (a string).
    return ""


# =============================================================================
# THE MORSE CODE STATION  (given - this is how your two functions get used)
# =============================================================================
print("Board:", hw.board_info())
print("Morse station. Choose a mode each round.")

while True:
    mode = input("\n[s]end or [r]eceive? (blank to quit) ")
    mode = mode.strip().lower()
    if mode == "":
        break

    if mode == "s" or mode == "send":
        message = input("  message to SEND: ")
        message = message.strip().upper()
        if message != "":
            send_message(message)             # <-- your function flashes the LED

    elif mode == "r" or mode == "receive":
        message = input("  message being sent to you: ")
        message = message.strip().upper()
        if message != "":
            hw.play(message)                  # fake sensor: make it "see" this message
            decoded = receive()               # <-- your function reads + decodes
            print("  you received:", decoded)

    else:
        print("  please type s or r")

print("done.")
